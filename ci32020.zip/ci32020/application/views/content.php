	<img src="<?php echo base_url(); ?>assets/foto.jpg" width="100%" height="50%"
<body>
</html>

</body>