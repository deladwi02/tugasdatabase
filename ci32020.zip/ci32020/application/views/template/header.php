
<head>
<meta http-equiv="Content-Type" content="text/php; charset=iso-8859-1"><style type="text/css">
<!--
body,td,th {
	font-family: Times New Roman, Times, serif;
}
.style5 {font-size: xx-small}
.style6 {
	font-size: small
}
.style7 {color: #3333FF}
-->
</style><div id="footer">
    	<marquee scrollamount="9">
		<div align="align">***********************************************************************************************@*********@********@******@***********@************@***********************************************************************************************************************************
        </marquee>
	    </div>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,
	initial-scale=1, sharink-to-fit=no">
	<!-- coding css bootstrap -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" herf="<?php echo base_url();?>/css/
	booststrap.css"/>
	<link rel="stylesheet" type="text/css" herf="<?php echo base_url();?>/css/
	Booststrap.min.css"/>
	<script type="text/javascript" src="../webprog/bootstrap-4/belajar_bootstrap/assets/js/jquery.js"></script>
	<script type="text/javascript" src="../webprog/bootstrap-4/belajar_bootstrap/assets/js/bootstrap.bundle.js"></script>
    <style type="text/css">
<title>Dela Dwi Septianti</title>

<!--
.style1 {
	font-size: medium
}
.style4 {
	font-family: "Times New Roman", Times, serif;
	font-size: x-large;
}
-->
    </style>
</head>


<body>

<div id="canvas">
  <div id="header"></h1>
<h1 align="center">SEKOLAH TINGGI TEKNOLOGI PAGAR ALAM</h1>
    <p align="center"><span class="style5"><strong>Jl. Masik Siagim  No.75 SimpangMbacang Kec.Dempo Tengah Kota Pagar Alam</strong><br>
      <strong>Website:<u>https//www.sttpagaralam.ac.id</u>,e-mail:sttp_2014@yahoo.com,  telp/Fax:(0730)621916</strong></span></p>
  </div>
  <form id="form1" name="form1" method="post" action="">
  <label></label>
  
        <h1 align="center" class="table-primary style4 style6">
          <input type="submit" name="button" id="button" value="Home" />
          </label>
          <label></label>
          <label>
          <input type="submit" name="button7" id="button7" value="Program Study">
          <input name="button2" type="submit" id="button2" value="Profile">
          <input type="submit" name="button3" id="button3" value="organisasi" />
          </label>
          <label></label>
          <label>
            
          <input type="submit" name="button5" id="button5" value="Akademik" />
          </label>
          <label>
            
          <input type="submit" name="button6" id="button6" value="Tentang" />
          </label>
          <label>
          <input type="submit" name="button4" id="button4" value="Unit Kerja">
          </label>
        </h1>
  </form>