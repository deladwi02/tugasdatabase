<div id="footer"></h1><hr/>
		<div align="right" class="style7">Copyright@2020 belajar web</div>
</div>
</h1><hr/>
	</div>