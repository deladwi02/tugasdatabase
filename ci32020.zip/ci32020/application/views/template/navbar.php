<p align="justify"</article>
 
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  <h1 align="center" class="style1">Selamat Datang Di Website STTP Pagar alam</h1>
  <p align="center" class="style1">&nbsp;</p>
  <p align="center" class="style1">&nbsp;</p>
  <p align="center" class="style1">&nbsp;</p>
  <p align="center" class="style1">&nbsp;</p>
  </article>
</div></h1><hr/>
</body> 