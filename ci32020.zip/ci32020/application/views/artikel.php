<!DOCTYPE html>
<html>
<head>
	<title>Artikel</title>
</head>
<body>
	<h3>Judul Artikel</h3>
	<p>Isi dari artikel</p>

</body>
</html>
