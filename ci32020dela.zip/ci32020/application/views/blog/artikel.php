<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,
	initial-scale=1, sharink-to-fit=no">
	<!-- coding css bootstrap -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" herf="<?php echo base_url();?>/css/
	booststrap.css"/>
	<link rel="stylesheet" type="text/css" herf="<?php echo base_url();?>/css/
	Booststrap.min.css"/>

	<title>Belajar Bootstrap</title>
</head>
<body>
	<div class="container">
	<div class="alert alert-warning"><h3 class="text text-primary">Judul Artikel</h3>
	<div class="alert alert-info"><p>Isi dari artikel</p></div>
</div>
		<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>
</html>